## IR decode

The ir_decode.ino is an Arduino sketch used to decode the IR code from a remote control.

## ESP32 IR Remote.pdf

This is the the presentation of a talk about the project at [Hackware 5.8 Meetup](https://youtu.be/qj1ApfKjbfU) event on 3 Dec, 2019.
